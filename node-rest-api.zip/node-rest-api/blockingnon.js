// Lets test the Javscript eexecution process.
// synhronous
console.log("1");// step 1
console.log("2");// step 2

// adding at this line a call for aynshroonus  function
setTimeout(() => {

    console.log("5");
    
},4000);  // step 3

console.log("3");// step 4
console.log("4");// step 5

// javascript provides an asynhronous function



// Timeout= millesconds
// ie 1000ms=1sec
