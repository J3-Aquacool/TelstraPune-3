const express = require('express'); // Import Express
const app = express(); // Create an Express application
const PORT = 9090; // Define the port on which the server will run

// Middleware function  first
const  first = function (req, res, next) {
    console.log('first');
    next(); // Pass control to the next middleware function
}

// Middleware function second
const second = function (req, res, next) {
    console.log('second');
    next(); // Pass control to the next middleware function
}

// Final route handler third
const third = function (req, res) {
    res.send('Hello from server to client'); // Send a response to the client
}

// Define a route with multiple callbacks
app.get('/chain/c', [first, second, third]);

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});