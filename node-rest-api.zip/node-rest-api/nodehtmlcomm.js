const express = require('express');
const bodyParser = require('body-parser'); //npm install express body-parser
const path = require('path');

const app = express();

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// Serve the HTML page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'first.html'));
});

// Handle form submission
app.post('/submit', (req, res) => {
    const name = req.body.name;
    res.send(`<h1>Welcome ${name}!</h1>`);
});

// Start the server
const port = 3000;
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});