const express = require('express');
const runmultiplerouter = express.Router();

// Middleware that logs the time of the request
runmultiplerouter.use((req, res, next) => {
    console.log('Time: ', Date.now());
    next();
});

// Route for /media/sports
runmultiplerouter.get('/sports', (req, res) => {
    res.send('Lets list all sports channel');
});

// Route for /media/movie
runmultiplerouter.get('/movie', (req, res) => {
    res.send('Lets list the movies channel');
});

module.exports = runmultiplerouter;
