const express = require('express')
const users = require('./users.json')
const fs=require('fs')

const app=express()

// lets enable a middle ware plugin
app.use(express.urlencoded({extended:false}))
const port=9090

app.get("/udata",(req,res)=>
{
    return res.json(users);
}
)

app.get("/udata/:id",(req,res)=>
    {
const id =Number (req.params.id);
const userdata=users.find(userdata => userdata.id==id);
        return res.json(userdata);
    }
);
    app.post("/udata",(req,res)=>
        {
            const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
//const body=req.body;
console.log("Returned Body data:",body)
// lets now add this data to json file
users.push(body);
// now lets write this to the file

fs.writeFile("./users.json",JSON.stringify(users,null,2),(err,data)=>
{
return res.json({status:"Success"})

})
        });

app.listen(port,()=>console.log("Server Started"))

