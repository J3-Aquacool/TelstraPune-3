const express = require('express');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');//npm install express jsonwebtoken body-parser
const app = express();
const PORT = 3000;
const SECRET_KEY = 'mykeyforusername'; // Use a strong secret key in production
app.use(bodyParser.json());

// Mock user
const user = {
    id: 1,
    username: 'omkar',
    password: 'password123'
};

// Login endpoint to generate a token
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    
    if (username === user.username && password === user.password) {
        // User authenticated
        const token = jwt.sign({ id: user.id,username:user.username }, SECRET_KEY, { expiresIn: '1h' });
        res.json({ token });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});

// Protected endpoint
app.get('/protected', (req, res) => {
    const token = req.headers['authorization'];

    if (!token) {
        return res.status(401).json({ message: 'Access token is missing or invalid' });
    }

    jwt.verify(token, SECRET_KEY, (err, decoded) => {
        if (err) {
            return res.status(401).json({ message: 'Invalid token' });
        }

        // Token is valid
        res.json({ message: 'Protected data', userId: decoded.id });
    });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});