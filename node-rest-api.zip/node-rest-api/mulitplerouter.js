
const express = require('express');
const app = express();
const PORT = 9090;

// Import the router middleware
const mediaRouter = require('./runmultiplerouter');

// Use the router with a base path of /animal
app.use('/media', mediaRouter);

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});