const express = require('express');
const { body, validationResult } = require('express-validator'); //npm install express-validator
const app = express();

app.use(express.json()); // For parsing application/json
app.post('/user', [
    // Validation rules
    body('username').isString().notEmpty().withMessage('Username is required'),
    body('email').isEmail().withMessage('Invalid email address'),
    body('age').isInt({ min: 0 }).withMessage('Age must be a positive integer'),
  ], (req, res) => {
    // Handle validation results
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
  
    // Process request if validation passed
    const { username, email, age } = req.body;
    res.status(200).json({ message: 'User data is valid', data: { username, email, age } });
  });
  
  app.listen(3000, () => {
    console.log('Server is running on port 3000');
  });
  