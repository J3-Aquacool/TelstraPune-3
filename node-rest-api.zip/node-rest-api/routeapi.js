const express = require('express')
const users = require('./users.json')
const fs=require('fs')

const app=express()

const port=9090

app.get("/udata",(req,res)=>
{
    return res.json(users);
});


app.route("/udata/:id").get((req,res)=>
    {
const id =Number (req.params.id);
const userdata=users.find(userdata => userdata.id==id);
        return res.json(userdata);
    }).put((req,res)=>
{
    return res.json({status:"Lets code later"})
}
).delete((req,res)=>{

    return res.json({status:"lets code later"})
});

    

app.listen(port,()=>console.log("Server Started"))

