const express = require('express')  // load the  module express server
const mongoose= require('mongoose')//npm install mongodb
// connection

mongoose.connect('mongodb://127.0.0.1:27017/userapp')


const app=express()// creating on demand an express server



app.use(express.urlencoded({extended:false}))
app.use(express.json());
console.log("conneted to db")

const userSchema=new mongoose.Schema({

_id:
{
type:Number,
required:true

},

    firstName:
{
type:String,
required:true
},
lastName:
{
type:String
},
email:{
type:String,
required:true,
unique:true
},


}); // schema creation complete

//lets create a class to map to this schema/model
const User=mongoose.model("user",userSchema)

app.post("/add",async(req,res)=>
{
const body=req.body;

const result=await User.create({
_id:body._id,
firstName:body.firstName,
lastName :body.lastName,
email:body.email

});
console.log("Result is:"+result)
return res.status(201).json({msg:"sucess"});

});

app.get("/disp",async(req,res)=>
    {
try
{
    const data=await User.find({});
  
    console.log("Result is:"+data)
    return res.status(200).json({msg:"success",data: data});
    
}catch (error) {
    console.error("Error fetching data:", error);
    return res.status(500).json({ msg: "Error fetching data" });
  } 

});
    


app.get("/search/:eid",(req,res)=>
    {
        const empid =Number(req.params.eid);
  
        User.findOne({ _id: empid })
        .then(userdata => {
          if (userdata) {
            return res.status(200).json({ msg: "Found success", data: userdata });
          } else {
            return res.status(404).json({ msg: "User not found" });
          }
        })
        .catch(err => {
          console.error("Error fetching data:", err);
          return res.status(500).json({ msg: "Error fetching data" });
        });


    
    

    });
    

    app.delete("/delete/:eid", async (req, res) => {
        const empid = Number(req.params.eid); // Convert empid to a number
      
        try {
          const result = await User.deleteOne({ _id: empid });
      
          if (result.deletedCount > 0) {
            return res.status(200).json({ msg: "User deleted successfully" });
          } else {
            return res.status(404).json({ msg: "User not found" });
          }
        } catch (err) {
          console.error("Error deleting user:", err);
          return res.status(500).json({ msg: "Error deleting user" });
        }
      });


app.listen(9090,()=>console.log("Server Started")) // create and start the server
