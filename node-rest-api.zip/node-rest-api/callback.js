function disp(fetchdata)
{
  console.log("Im used for displaying");
fetchdata();
    
}
function accept()
{
  console.log("Iam use for getting the data");
}



disp(accept);  // callback functions
