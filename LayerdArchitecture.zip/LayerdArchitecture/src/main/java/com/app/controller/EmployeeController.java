package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.entity.Employee;
import com.app.service.impl.EmployeeServiceImpl;

@RestController
public class EmployeeController {

	
	@Autowired
	EmployeeService es;
	
	
	@PostMapping("/add")
	public void addEmpdata(@RequestBody Employee emp)
	{
		es.createEmployee(emp);
		
	}
	@DeleteMapping("/del/{id}")
	
public void DeleteEmpdata(@PathVariable Integer id)
{
	es.removeEmployee(id);
	
}
	
}
