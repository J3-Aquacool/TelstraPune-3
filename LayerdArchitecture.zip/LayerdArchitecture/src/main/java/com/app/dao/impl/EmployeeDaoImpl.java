package com.app.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.EmployeeDao;
import com.app.entity.Employee;
import com.app.repo.EmployeeRepository;
@Service
public class EmployeeDaoImpl implements EmployeeDao
{

	
	@Autowired
	EmployeeRepository emprepo;
	@Override
	public void saveEmployee(Employee employee) {
		emprepo.save(employee);
		
	}
	
	@Override
	public void remove(Integer employee) {
		// TODO Auto-generated method stub
		emprepo.deleteById(employee);
		
	}

}
