package com.app.dao;

import com.app.entity.Employee;

public interface EmployeeDao {
void saveEmployee(Employee employee) ;
void remove(Integer employee) ;
}
