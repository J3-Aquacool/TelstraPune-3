package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.EmployeeDao;
import com.app.entity.Employee;
import com.app.service.EmployeeService;

@Service
public class EmployeeService 
{
	@Autowired
	EmployeeDao empdao;

	
	public void createEmployee(Employee e) {
		
		empdao.saveEmployee(e);
		
	}


	public void removeEmployee(Integer e) {
		// TODO Auto-generated method stub
		empdao.remove(e);
	}

}
