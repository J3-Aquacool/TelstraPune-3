package com.bms.app.exceptionhandlers;

public class InvoiceNotFoundException extends RuntimeException {

   
    public InvoiceNotFoundException() {
        super();
    }

    public InvoiceNotFoundException(String customMessage) {
        super(customMessage);
    }
}