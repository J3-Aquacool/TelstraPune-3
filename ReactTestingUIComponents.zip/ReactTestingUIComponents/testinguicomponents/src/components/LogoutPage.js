import React from 'react'


function LogoutPage() {
  return (
    <div>LogoutPage
    
    <h1 data-testid="abc">This is the Heading component</h1>
    <h2 data-testid="xyz">This is the Heading component 1</h2>
    <h3>This is the Heading component 2</h3>
    <h4>This is the Heading component 3</h4>
    <input type="text" placeholder='nameofemp'/>
    
<p role='paragraph'> Testing the Paragraph component</p>
<button>Click Here</button>
    
    </div>
  )
}

export default LogoutPage
