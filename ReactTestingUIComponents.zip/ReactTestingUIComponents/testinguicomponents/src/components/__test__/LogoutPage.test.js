import { render, screen } from '@testing-library/react';
import LogoutPage from '../LogoutPage';
test('Check the p tag content', () => {
    render(<LogoutPage/>)
const paraelement=screen.getByText('Testing the Paragraph component');
expect(paraelement).toBeInTheDocument();


});


test('Check the Button tag content', () => {
    render(<LogoutPage/>)
const paraelement=screen.getByText('Click Here');
expect(paraelement).toBeInTheDocument();


});


test('Check the Button component', () => {
    render(<LogoutPage/>)
const paraelement=screen.getByRole('paragraph')
expect(paraelement).toBeInTheDocument();


});



test('Check the heading  role component', () => {
    render(<LogoutPage/>)
const paraelement=screen.getAllByRole('heading')
expect(paraelement.length).toBe(4);
});


test('Check the heading  with test-id', () => {
    render(<LogoutPage/>)
const paraelement=screen.getByTestId("abc")
expect(paraelement.textContent).toBe("This is the Heading component");
});


test('Check the h1 tag content', () => {
       render(<LogoutPage/>)
const h1element=screen.queryByText('This is the Heading component 6');
expect(h1element).toBeNull().toBeInTheDocument();


});

test('Check the h2 tag', () => {
    render(<LogoutPage/>)
const h1element=screen.getByTestId("xyz")
expect(h1element.textContent).toBe('This is the Heading component 1');


});