import { render, screen } from '@testing-library/react';
import HomePage from './HomePage';


// test('Check the h1 tag content', () => {
//        render(<HomePage/>)
// const h1element=screen.getByText('This is the Heading component');
// expect(h1element).toBeInTheDocument();


// });


test('Check the p tag content', () => {
    render(<HomePage/>)
const paraelement=screen.getByText('Testing the Paragraph component');
expect(paraelement).toBeInTheDocument();


});


test('Check the Button tag content', () => {
    render(<HomePage/>)
const paraelement=screen.getByText('Click Here');
expect(paraelement).toBeInTheDocument();


});


test('Check the Button component', () => {
    render(<HomePage/>)
const paraelement=screen.getByRole('paragraph')
expect(paraelement).toBeInTheDocument();


});



test('Check the heading  role component', () => {
    render(<HomePage/>)
const paraelement=screen.getAllByRole('heading')
expect(paraelement.length).toBe(4);
});



test('Check the h1 tag content', () => {
       render(<HomePage/>)
const h1element=screen.queryByText('This is the Heading component');
expect(h1element).toBeInTheDocument();


});



// Notes npm install @testing-library/react
// npm test