import React from 'react'

function HomePage() {
  return (
    <div>HomePage
    <h1 data-testid="firstheader">This is the Heading component</h1>
    <h2>This is the Heading component 1</h2>
    <h3>This is the Heading component 2</h3>
    <h4>This is the Heading component 3</h4>
<p role='paragraph'> Testing the Paragraph component</p>
<button>Click Here</button>
    </div>

  )
}

export default HomePage