const express=require('express')
const body_parser = require('body-parser')
const cors = require("cors");


const {createProxyMiddleware}=require('http-proxy-middleware')
const Eureka = require('../eurekaserviceregistry/eurekaclient')

const port=3004

// defining routes
const app=express();
//app.use(cors());
//app.use(body_parser())

app.get('/', (req, res) => {
    res.send('Welcome to the API Gateway');
});

 const routes=
 {
 '/users':'http://localhost:3000',
 '/products':'http://localhost:3001',
'/orders':'http://localhost:3002'
}
// // creating proxy for each routes
 for(const route in routes)
 {
     const target=routes[route]
     console.log(target)

 app.get(route,createProxyMiddleware({target,changeOrigin: true ,logLevel: 'debug'}))
 }


/*app.get('/users', createProxyMiddleware({
cl    target: 'http://localhost:3000',
    changeOrigin: true,
    logLevel: 'debug'
}));
*/


app.use((err, req, res, next) => {
    
    console.error(err);

    res.status(500).send('Something went wrong!');
});

app.listen(port,()=>console.log("API-GTEWAY STARTED"))






