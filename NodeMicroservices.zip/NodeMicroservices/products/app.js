const express=require('express')
const port=3001
const app=express()
app.get('/products',(req,res)=>{

    res.send("Message from product service")

})


app.listen(port,()=> console.log("Product Service Started"))
