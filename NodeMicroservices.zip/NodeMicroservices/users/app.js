const express=require('express')
const axios=require('axios')
const port=3000
const app=express()
// app.get('/users',async(req,res)=>{

//     const prodData= await axios.get('http://localhost:3001/products')
//     res.send("Message from user service"+ prodData.data)

// })


app.get('/users',(req,res)=>
    {

   // const prodData= await axios.get('http://localhost:3001/products')
   console.log("Inside Users Service")
    res.send("Message from user service")

})

app.listen(port,()=> console.log("User Service Started"))


