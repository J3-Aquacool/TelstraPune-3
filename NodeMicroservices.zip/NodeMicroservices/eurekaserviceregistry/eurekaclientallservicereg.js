const Eureka = require('eureka-js-client').Eureka;

// Get configuration from environment variables or defaults
const appName = process.env.APP_NAME || 'multiple-service';
const port = process.env.PORT || 7000;

const client = new Eureka({
    instance: {
        app: appName,
        hostName: 'localhost',
        ipAddr: '127.0.0.1',
        port: {
            '$': port
        },
        vipAddress: appName,
        dataCenterInfo: {
            '@class': 'com.netflix.appinfo.InstanceInfo$DefaultDataCenterInfo',
            name: 'MyOwn'
        }
    },
    eureka: {
        host: 'localhost',
        port: 8761,
        servicePath: '/eureka/apps/'
    }
});

client.start(error => {
    if (error) {
        console.error(`Error starting Eureka client for ${appName}:`, error);
    } else {
        console.log(`${appName} registered with Eureka`);
    }
});

module.exports = client;
