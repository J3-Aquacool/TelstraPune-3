const express = require('express')
const axios = require('axios');

const port=3002
const app=express()
// app.get('/orders',(req,res)=>{

//     res.send("Message from orders service")

// })


// add the below code for microservice communitaion bettwee 2 microsrvices using axios
// install axios and use async await for asynchronous communication
app.get('/orders', async (req, res) => {
    try {
        // Send a request to the product service
        const response = await axios.get('http://localhost:3001/products');
        
        // Handle the response from the product service
        const productServiceMessage = response.data;

        res.send(`Message from orders service. Product service says: ${productServiceMessage}`);
    } catch (error) {
        console.error('Error calling product service:', error);
        res.status(500).send('Error communicating with product service');
    }
});



app.listen(port,()=> console.log("Order Service Started"))
