package com.example.demo.topics;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KafkaTopicCreation {

	// This class im creating to progamtically create new topic which is 
	// practise follwed in real-time 
	
	@Bean
	public NewTopic createTopic()
	{
		
	return new NewTopic("festival-sale", 3, (short)1);	
	}
}
