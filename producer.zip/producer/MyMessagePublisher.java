package com.example.demo.service;

import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;


@Service
public class MyMessagePublisher {


@Autowired
KafkaTemplate<String, Object> template;

public void sendMessageToTopic(String message)
{
	
	//CompletableFuture <SendResult<String,Object>> future=template.send("demotopic", message);
	CompletableFuture <SendResult<String,Object>> future=template.send("festival-sale", message);
	
	future.whenCompleteAsync((result,ex)->
	{
		
		if(ex==null)
		{
			
			System.out.println("Sent Message:[" +message+ "]"+  "Offset=["+result.getRecordMetadata().offset()+"]");
		}

		else
		{
			
			System.out.println("Unable to send Message:" +ex.getMessage());
		}
	});
	
	
	
}

}
