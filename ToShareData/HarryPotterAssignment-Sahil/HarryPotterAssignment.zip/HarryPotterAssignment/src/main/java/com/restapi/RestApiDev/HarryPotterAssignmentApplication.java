package com.restapi.RestApiDev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HarryPotterAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(HarryPotterAssignmentApplication.class, args);
	}

}
