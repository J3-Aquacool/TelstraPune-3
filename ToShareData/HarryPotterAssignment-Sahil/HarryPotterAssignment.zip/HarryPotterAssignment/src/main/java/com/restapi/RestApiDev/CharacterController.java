package com.restapi.RestApiDev;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class CharacterController {
	
	List<Character> charList = new ArrayList<Character>();
	
	@PostMapping("/addcharacters")
	public ResponseEntity<?> addCharacter(@RequestBody ArrayList<Character> list)
	{
		charList = list;
		System.out.println("Added");
		return new ResponseEntity<List<Character>>(charList,HttpStatus.OK) ;
		
	}
	
	@GetMapping("/find/gryffindor")
	public List<Character> getGryffindorCharacters(){
		
		String s = "Gryffindor";
		List<Character> gryfList = new ArrayList<Character>();
		for(Character c : charList) {
			if(s.equals(c.getHouse())) {
				gryfList.add(c);
			}
		}
		return gryfList;
	}
	
	@GetMapping("/find/alive")
	public List<Character> getAliveCharacters(){
		
		String s = "Yes";
		List<Character> aliveList = new ArrayList<Character>();
		for(Character c : charList) {
			if(s.equals(c.getDie())) {
				aliveList.add(c);
			}
		}
		return aliveList;
	}
	
	@GetMapping("/find/family")
	public List<Character> getFamilyCharacters(){
		
		String s = "Family";
		List<Character> familyList = new ArrayList<Character>();
		for(Character c : charList) {
			if(s.equals(c.getStatus())) {
				familyList.add(c);
			}
		}
		return familyList;
	}
	
	@GetMapping("/find/faculty/died")
	public List<Character> getFacultyDiedCharacters(){
		
		String s = "No";
		String r = "Faculty";
		List<Character> diedList = new ArrayList<Character>();
		for(Character c : charList) {
			if(r.equals(c.getRole())) {
				
				if(s.equals(c.getDie())) {
					diedList.add(c);
				}
			}
		}
		return diedList;
	}
}
