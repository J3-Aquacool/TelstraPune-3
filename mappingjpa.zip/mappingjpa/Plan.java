package com.foodie.app.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "plans")

public class Plan {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int planid;

	@NotNull(message = "Plan Name should not be null")
	@NotEmpty(message = "Please provide a planname")
	@Pattern(regexp = "^[a-zA-Z ]+$", message = "plan name must be a string")

	String planname;

	@NotNull(message = "Price cannot be Null")
	@Min(1)
	int price;

	public int getPlanid() {
		return planid;
	}

	public void setPlanid(int planid) {
		this.planid = planid;
	}

	public String getPlanname() {
		return planname;
	}

	public void setPlanname(String planname) {
		this.planname = planname;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@OneToMany(mappedBy = "plan", fetch = FetchType.LAZY, cascade = { CascadeType.REMOVE })
	List<Subscription> subscriptions;

	public Plan(String planname, int price) {

		this.planname = planname;
		this.price = price;

	}

	public Plan() {

	}

	public Plan(int planid) {
		this.planid = planid;

	}

}
