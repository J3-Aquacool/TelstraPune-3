package com.foodie.app.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

@Entity
@Table(name = "subscriptions")
public class Subscription {

	@Id
	// @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Min(1)
	@NotNull(message = "Subscription Id cannot be null")
	int subscriptionid;

	@Past
	LocalDate startdate;

	// String startdate;
	@Min(1)
	int customerid;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)

	@JoinColumn(name = "planid", referencedColumnName = "planid")

	private Plan plan;

	public Subscription() {
		super();
	}

	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

	/*
	 * public Subscription(int customerid, int subscriptionid, String startdate) {
	 * this.customerid = customerid; this.subscriptionid = subscriptionid;
	 * this.startdate = startdate;
	 * 
	 * }
	 */
	public LocalDate getStartdate() {
		return startdate;
	}

	public void setStartdate(LocalDate startdate) {
		this.startdate = startdate;
	}

	public Subscription(int customerid, int subscriptionid, LocalDate startdate) {
		this.customerid = customerid;
		this.subscriptionid = subscriptionid;
		this.startdate = startdate;

	}

	public int getSubscriptionid() {
		return subscriptionid;
	}

	public void setSubscriptionid(int subscriptionid) {
		this.subscriptionid = subscriptionid;
	}

	/*
	 * public String getStartdate() { return startdate; }
	 * 
	 * public void setStartdate(String startdate) { this.startdate = startdate; }
	 */

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	@Override
	public String toString() {
		return "Subscription [subscriptionid=" + subscriptionid + ", startdate=" + startdate + ", customerid="
				+ customerid + ", plan=" + plan + "]";
	}

}
