package com.foodie.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceMesh3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
