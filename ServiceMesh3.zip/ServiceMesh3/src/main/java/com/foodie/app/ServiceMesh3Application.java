package com.foodie.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceMesh3Application {

	public static void main(String[] args) {
		SpringApplication.run(ServiceMesh3Application.class, args);
	}

}
