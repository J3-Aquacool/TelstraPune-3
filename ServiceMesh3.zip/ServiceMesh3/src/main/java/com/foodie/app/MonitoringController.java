package com.foodie.app;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class MonitoringController {

	@GetMapping("/greetings")
	public String getAllWell() {
		return "Happening a lot in Mesh";
	}

}
