package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BrokenAuthenticationController {


    private static final Map<String, String> udata = new HashMap<>();

    static {
     
       udata.put("user1", "user123");
        udata.put("user2", "89765");
        udata.put("admin", "admin");
    }

    //  incorrect way of login
    @GetMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) {
        //
        if (udata.containsKey(username)) {
           
            if (udata.get(username).equals(password)) {
                return "Welcome, " + username + "!";
            } else {
                return "Invalid password!";
            }
        }
        return "User not found!";
    }
}
