import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;




@RestController
@RequestMapping("/logmonitoring")
public class LogMonitoring{

private static final Logger logger = LoggerFactory.getLogger(LogMonitoring.class);

   
    @GetMapping("/withoutlogging")
    public String noLogging() {
      
        return "No logging for this endpoint"; 
    }

    
    @GetMapping("/withlogging")
    public String withLogging() {
        logger.info("Accessing /with-logging endpoint");
// some lgic here
        return "Endpoint with logging enable";
    }

   
    @GetMapping("/sensitiveinfo")
    public String sensitiveInfo() {
        String sdata = "Sensitive Data";
        logger.error("Sensitive data accessed: {}", sdata);
                return "Sensitive data should not be logged";
    }
}