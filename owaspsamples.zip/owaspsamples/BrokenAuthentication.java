package com.example.demo;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class BrokenAuthentication {

	@GetMapping("/admin")
	public String adminPage() {
	    return "Only admin.";
	}
	
	
	@GetMapping("/secureadmin")
    public String secureAdminPage() {
        return "securing admin users";
    }
}
