package com.app.advices;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
@ResponseBody
public class ControllerAdvisor {

	 @ExceptionHandler()

     public String handleException(Exception ex) {

             return "Exception caught in ControllerAdvisor.handleException | " + " Exception Type: " + ex.getClass().getName();

     }

    

     @ExceptionHandler()

     public String handleArrayIndexOutOfBoundsException(ArrayIndexOutOfBoundsException ex) {

             return "Exception caught in ControllerAdvisor.handleArrayIndexOutOfBoundsException | " + " Exception Type: ArrayIndexOutOfBoundsException";

     }
}
