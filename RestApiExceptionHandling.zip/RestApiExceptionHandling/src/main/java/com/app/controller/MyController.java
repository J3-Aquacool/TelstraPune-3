package com.app.controller;

import java.io.IOException;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class MyController {
	@RequestMapping("/hello")

    public String sayHello() {

            return "Hello!";

    }

   

    @RequestMapping(value = "/demo/not-exist", method = RequestMethod.GET)

    public String oneFaultyMethod() {

            if (true) {

                    throw new NullPointerException("Demo error message");

            }

            return null;

    }



    @ExceptionHandler({ NullPointerException.class, ArrayIndexOutOfBoundsException.class, IOException.class })

    public String handleException(NullPointerException ex) {

            return "Exception caught using @ExceptionHandler from DemoController";

    }
}


//http://localhost:8080/demo/not-exist