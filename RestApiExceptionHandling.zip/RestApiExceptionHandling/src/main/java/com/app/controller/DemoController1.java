package com.app.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class DemoController1 {
	@RequestMapping(value = "/demo1/not-exist", method = RequestMethod.GET, headers = "Accept=*/*")

    public String oneFaultyMethod() {

            if (true) {

                    throw new ArrayIndexOutOfBoundsException("Demo error message");

            }

            return null;

    }
}

// http://localhost:8080/demo2/not-exist
//http://localhost:8080/demo1/not-exist
