package com.app.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController2 {
	 @RequestMapping(value = "/demo2/not-exist", method = RequestMethod.GET, headers = "Accept=*/*")

     public String oneFaultyMethod() {

             if (true) {

                     throw new NullPointerException("Demo error message");

             }

             return null;

     }
}
