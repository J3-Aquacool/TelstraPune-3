const mongoose = require('mongoose');
//const { MongoMemoryServer } = require('mongodb-memory-server');
const request = require('supertest');
const app = require('./nodemongo'); // Import the Express app

// beforeAll(async () => {
//     await mongoose.connect('mongodb://localhost:27017/testdb', {
//       useNewUrlParser: true,
//       useUnifiedTopology: true,
//     });
//   });
// // Clean up after all tests have run
// afterAll(async () => {
//     await mongoose.connection.db.dropDatabase(); // Drop the test database to clean up
//     await mongoose.disconnect(); // Disconnect from the database
//   });


const user = {
  _id: 18797675666,
  firstName: 'abc3',
 lastName: 'xyz',
  email: 'abc1.xyz123558rr77@yahoo.com',
};

JsonWebTokenError
  //  describe('User API Tests', () => {
  //  test('should create a new user', async () => {
     



  // const res = await request(app).post('/add').send(user);
  //    expect(res.statusCode).toBe(201);
  //    expect(res.body.msg).toBe("success");

  //  });




   describe('User Delete API Test', () => 
     {
    test('should delete a user', async () =>
       {
         const res = await request(app).delete('/delete/18798').send(user);
         expect(res.statusCode).toBe(200);
          expect(res.body.msg).toBe("User deleted successfully");
       })
      })




      describe('Find User  API Test', () => 
        {
        test('should  find  a user', async () =>
           {
            const res = await request(app).get('/search/1879767566');
            
             expect(res.statusCode).toBe(200);
              expect(res.body.msg).toBe("Found success");
           })
          })
    


  //  });