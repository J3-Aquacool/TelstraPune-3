const express = require('express')  // load the  module express server
const users = require('./users.json')

const fs=require('fs')
const cors = require('cors');

const swaggerUi = require('swagger-ui-express');
const swaggerJsdoc = require('swagger-jsdoc');
const app=express()// creating a express server


const options = {
    definition: {
      openapi: '3.0.0',
      info: {
        title: 'Node.js API Documentation',
        version: '1.0.0',
      },
    },
    apis: ['./*.js'], // Path to the API docs
  };
  const swaggerSpec = swaggerJsdoc(options);

  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
// lets enable a middle ware plugin
app.use(express.urlencoded({extended:false}))

const corsOptions = {
    origin: 'http://localhost:3000', // Allow only this origin
    methods: 'GET,POST',            // Allow only these methods
    allowedHeaders: 'Content-Type',  // Allow only these headers
  };
  
app.use(cors(corsOptions));



app.use(express.json());// this line needs to be added if sending the data using raw json



const port=9090  // will start the server using the port


app.get("/udata",(req,res)=>
{
    return res.json(users);
})




// get:  /udata/14--->

//http: 90090/udata/101 : ftecth tehd etails of the user whose id matches 12
// How will this be read 


/**
 * @swagger
 * /users:
 *   get:
 *     summary: Retrieve a list of users
 *     responses:
 *       200:
 *         description: A list of users
 */
app.get("/udata/:empid",(req,res)=>
    {
const id =Number(req.params.empid);
//101

const userdata=users.find(userdata => userdata.id==id);
        return res.json(userdata);
    }
);


    app.post("/udata",(req,res)=>
        {
//            const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
const body=req.body;
console.log("Returned Body data:",body)
// lets now add this data to json file
users.push(body);
// now lets write this to the file

fs.writeFile("./users.json",JSON.stringify(users),(err,data)=>
{
return res.json({status:"Success"})

})
        });



        app.get("/mulitple/:uid/uname/:username",(req, res) => {
            // Log the route parameters to the console
            console.log("hello")
         console.log(req.params);
        
            //Send a response back to the client
       // return  res.send("hello");
        return res.send(`${req.params.uid} from ${req.params.username}!`); 
        });



app.listen(port,()=>console.log("Server Started")) // create and start the server

