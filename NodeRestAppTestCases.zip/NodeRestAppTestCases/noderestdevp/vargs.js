let printnum=(...number)=>
    {
    console.log(number);
    
    }
    printnum(1,3,4,4);
    