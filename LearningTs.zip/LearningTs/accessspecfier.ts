class Employee {

    public eid: number;

    private phone: number;

    protected adharid: number;

}

 //EFFECT on instance

var empobj = new Employee();

empobj.eid; // okay

empobj.phone // ERROR : private

empobj.adharid; // ERROR : protected

 

// EFFECT ON CHILD CLASSES

class Clerk extends Employee {

    constructor() {

      super();

        this.eid; // okay

        this.phone; // ERROR: private

        this.adharid; // okay

    }

}

