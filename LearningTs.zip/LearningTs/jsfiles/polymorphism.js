class WorkerObj {
    work() {
        console.log("lets work");
    }
}
class ClerkObj extends WorkerObj {
    work() {
        console.log("lets do clerical work");
    }
}
class ManagerObj extends WorkerObj {
    work() {
        console.log("lets do Managerial work");
    }
}
let ref = new ManagerObj();
ref.work();
