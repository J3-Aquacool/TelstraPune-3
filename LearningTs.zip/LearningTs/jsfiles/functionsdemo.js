/*
function functionName(parmeter1: type1, parmeter2: type2, ...): returnType {

        return valueOfType_returnType;

}

function functionName(parmeter1: type1, parmeter2: type2): void {

        return valueOFType_void;

        //Or return nothing

}

*/
function sum(x, y) {
    return x + y;
}
function printOnConsole(text) {
    console.log(text);
}
//IIFE
(function sum(x, y) {
    return x + y;
})(10, 20);
// Annonymous
var calculate = function (x, y) {
    return x + y;
};
//arrow
let sumfun = (x, y) => { return x + y; };
let square = x => x * x;
//optional parameters
/*
function func1( x : number, y: number, z? : number ): number
{

       return 0;

}

function func2( x : number, y? : number, z? : number ): number {

       
return 0;
}

function func3( x? : number, y? : number, z? : number ): number {

       return 0;

}
*/
// Possible ways for default  paramters
function func1(x, y, z = 30) {
    return x + y + z;
}
function func2(x, y = 20, z = 30) {
    return x + y + z;
}
function func3(x = 10, y = 20, z = 30) {
    return x + y + z;
}
func1(10, 20);
func2(10);
func3();
/*
Functions as Parameters
If function is returning value then its return value can be serverd
for the another functions arguments.


*/
function add(x, y) { return x + y; }
function multiply(a, b) { return a * b; }
let ans = multiply(10, add(20, 30));
