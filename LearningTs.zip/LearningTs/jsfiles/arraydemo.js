let numArray;
numArray = [1, 3, 4, 6];
console.log(numArray[0]);
//or
let numArray1 = [9, 5, 6, 7];
console.log(numArray1);
// suppose you want the above 4 values to be assigned to four different varaibles
let [a, b, c, d] = numArray1;
// this can be alsow written as let a:number and so on
console.log(a);
// another way
let strArray;
strArray = ["java", "javascript", "ts"];
console.log(strArray);
//TypeScript Tupel
let tupleval = ['Abc', 100, true];
