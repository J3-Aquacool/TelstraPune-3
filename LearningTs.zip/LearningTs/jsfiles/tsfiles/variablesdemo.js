var phonenumber;
//or
var phonenumber = 10000;
//or
var phonenumber = 1090888;
console.log(typeof phonenumber);
var address;
var statusp;
//const price:number;// compile error
const price = 100.5;
let message = "Typsript";
let helloMessage = 'Hello Dear Reader!';
// Multilple string with back tick `
let description = `TypeScript learning is must before Angular and React.

Google adapted TypeScript language developed at Microsoft to Angular.`;
