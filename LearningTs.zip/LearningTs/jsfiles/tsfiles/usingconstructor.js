class Provider {
    constructor(serviceprovider, servictype) {
        this.serviceprovider = serviceprovider;
        this.servictype = servictype;
        this.serviceprovider = serviceprovider;
        this.servictype = servictype;
    }
}
// Now what happens if the parameters are assigned with access specfieres and the same variable
// aviailbe within class?
/*class Provider_V1 {

    // Error
    serviceprovider:string
    servicetype:string
    constructor(public serviceprovider: string, public servictype: string) {

        this.serviceprovider = serviceprovider;

        this.servictype=servictype

    }

}
*/ 
