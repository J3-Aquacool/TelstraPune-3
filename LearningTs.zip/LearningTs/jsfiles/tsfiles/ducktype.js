function playSport(sport) {
    sport.play();
}
class Cricket {
    play() {
        console.log("Lets Play Cricket");
    }
}
class FootBall {
    play() {
        console.log("Lets Play Foot Ball!");
    }
}
// Create instances of both classes
const crickt = new Cricket();
const Ftball = new FootBall();
playSport(crickt);
playSport(Ftball);
