let age;
age = 10;
console.log(age);
