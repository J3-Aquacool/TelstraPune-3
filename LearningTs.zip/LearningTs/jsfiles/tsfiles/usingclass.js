class Employee {
    constructor(eid, ename) {
        this.eid = eid;
        this.ename = ename;
    }
    displayEmployee(empobj) {
        return new Employee(empobj.eid, empobj.ename);
    }
}
let eobj = new Employee(100, "abc");
console.log(eobj);
