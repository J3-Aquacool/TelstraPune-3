class CreateOrder {
    orderfood(qty, dish) {
        console.log("some code here");
    }
    sendorderotp(pin) {
        return pin;
    }
}
let order = new CreateOrder();
order.orderfood(10, 'Rice');
let x = order.sendorderotp(7889);
console.log(x);
// additional learning
// class can be also implemented has interface only if  a class has uninitialesd members
class SomeInterface {
}
class TestClass {
    constructor() {
        this.x = 100;
    }
    data() {
        return x;
    }
}
