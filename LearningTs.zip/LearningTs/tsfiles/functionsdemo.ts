/*
function functionName(parmeter1: type1, parmeter2: type2, ...): returnType {

        return valueOfType_returnType;

}

function functionName(parmeter1: type1, parmeter2: type2): void {

        return valueOFType_void;

        //Or return nothing

}

*/

function sum( x : number, y : number ): number {

    return x + y;

}

function printOnConsole(text: any): void {

    console.log(text);

}

//IIFE
(function sum( x : number, y : number ): number {

    return x + y;

}

)(10, 20);

// Annonymous
var calculate = function ( x : number, y : number ): number {

    return x + y;

}

//arrow
let sumfun = (x, y) => { return x + y; };
let square = x =>   x *x ;

//optional parameters
/*
function func1( x : number, y: number, z? : number ): number 
{

       return 0;

}

function func2( x : number, y? : number, z? : number ): number {

       
return 0;
}

function func3( x? : number, y? : number, z? : number ): number {

       return 0;

}
*/
// Possible ways for default  paramters

function func1( x : number, y : number, z=30 ): number {

    return x + y + z;

}

function func2( x : number, y = 20, z=30 ): number {

    return x + y + z;

}

function func3( x = 10, y = 20, z = 30 ): number {

    return x + y + z;

}
    
func1(10, 20);

func2(10);

func3();


/*
Functions as Parameters
If function is returning value then its return value can be serverd 
for the another functions arguments.


*/


function add(x: number, y: number): number { return x + y; }

function multiply(a: number, b: number): number { return a * b; }

let ans: number = multiply(10, add(20, 30));