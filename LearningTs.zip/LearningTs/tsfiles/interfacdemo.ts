interface OnlineOrder
{

    greetings: string;

    orderfood(qty: number, dish: string): void;

    sendorderotp(pin: number): number;

}

class CreateOrder implements OnlineOrder
{
    greetings: string;
    orderfood(qty: number, dish: string): void {
       console.log("some code here")
    }
    sendorderotp(pin: number): number {
        return pin;
    }

    
}
let order:OnlineOrder =new CreateOrder()
order.orderfood(10,'Rice')
let x=order.sendorderotp(7889);
console.log(x);



// additional learning

// class can be also implemented has interface only if  a class has uninitialesd members

class SomeInterface
{
    x:number;
}

class TestClass implements SomeInterface
{
    x=100;
 data(): number
 {

    return x;
 }   
}