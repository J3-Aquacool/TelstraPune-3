class Customer
{
constructor()
{
    console.log("Customer class")
}
 printCustomer() :void
{

console.log("Customer method")
}

}

class PrepaidCustomer extends Customer
{

    constructor()
    {
        // compulsary you have to make acall to super
    super()
super.printCustomer()
}

}

var obj=new PrepaidCustomer();
