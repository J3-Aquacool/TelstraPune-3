var phonenumber: number
//or
var phonenumber: number=10000
//or
var phonenumber=1090888
console.log(typeof phonenumber)
var address:String
var statusp :boolean
//const price:number;// compile error

const price=100.5;


let message: string = "Typsript";

let helloMessage: string = 'Hello Dear Reader!';

// Multilple string with back tick `
let description: string = `TypeScript learning is must before Angular and React.

Google adapted TypeScript language developed at Microsoft to Angular.`

