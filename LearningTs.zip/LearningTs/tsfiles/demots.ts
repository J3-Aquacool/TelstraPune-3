let age:number;
age=10;
console.log(age);
