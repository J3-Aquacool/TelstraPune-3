class Employee {

    eid: number;

    ename: string;

    constructor(eid: number, ename: string) {

        this.eid = eid;

        this.ename = ename;

    }

    displayEmployee(empobj: Employee) {

        return new Employee(empobj.eid, empobj.ename);

    }

}

let eobj=new Employee(100,"abc");



console.log(eobj);
