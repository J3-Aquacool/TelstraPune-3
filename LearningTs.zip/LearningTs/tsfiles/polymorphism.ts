class WorkerObj
{

    work():void
    {
        console.log("lets work");
    }
}

class ClerkObj extends WorkerObj
{

    work():void
    {
        console.log("lets do clerical work");
    }
}

class ManagerObj extends WorkerObj
{

    work():void
    {
        console.log("lets do Managerial work");
    }
}




let ref:WorkerObj=new ManagerObj();
ref.work()