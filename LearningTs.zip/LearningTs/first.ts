function greet(mesg) {

    return "Greetings !!! for the Day " + mesg;

}

 

var greetings = "Welcome to Typescript";

 

document.body.innerHTML = greet(greetings);