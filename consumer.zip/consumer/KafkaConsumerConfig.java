package com.example.demo.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

@Configuration
public class KafkaConsumerConfig {

	
	Logger log=LoggerFactory.getLogger(KafkaConsumerConfig.class);
	
	
	@KafkaListener(topics="festival-sale",groupId="festive-offers")
	public void consume(String message)
	{
		log.info("Consumer consume the message {}:",message);
		
	}
	
	
	
	
	
	// Going Ahead if we want mulitple instances of consumers we can create like below
	
//	@KafkaListener(topics="festival-sale",groupId="festive-offers")
//	public void consume1(String message)
//	{
//		log.info("Consumer consume the message {}:",message);
//		
//	}
//	
//	
//	@KafkaListener(topics="festival-sale",groupId="festive-offers")
//	public void consume2(String message)
//	{
//		log.info("Consumer consume the message {}:",message);
//		
//	}
//	@KafkaListener(topics="festival-sale",groupId="festive-offers")
//	public void consume3(String message)
//	{
//		log.info("Consumer consume the message {}:",message);
//		
//	}
//	@KafkaListener(topics="festival-sale",groupId="festive-offers")
//	public void consume4(String message)
//	{
//		log.info("Consumer consume the message {}:",message);
//		
//	}
	
}
